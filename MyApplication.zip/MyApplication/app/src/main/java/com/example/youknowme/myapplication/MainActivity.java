package com.example.youknowme.myapplication;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.nfc.Tag;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.*;
import android.widget.*;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;

import java.io.*;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

import static java.lang.Boolean.TRUE;



public class MainActivity extends AppCompatActivity {
Button b1;
TextView t1;
String data,Name;
Boolean t;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        t=isNetworkAvailable();
        if(t==TRUE)
        Toast.makeText(getApplicationContext(),"internet connected", Toast.LENGTH_LONG).show();
        else
            Toast.makeText(getApplicationContext(),"internet not connected", Toast.LENGTH_LONG).show();
        t1=findViewById(R.id.t1);
        b1=findViewById(R.id.b1);
        b1.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                try{

                    // CALL GetText method to make post method call
                    GetText();
                }
                catch(Exception ex)
                {
                    Toast.makeText(getApplicationContext(),"url exception",Toast.LENGTH_LONG);
                }

            }
        });
    }


    public boolean isNetworkAvailable() {
        ConnectivityManager cm = (ConnectivityManager)
                getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = cm.getActiveNetworkInfo();
        // if no network is available networkInfo will be null
        // otherwise check if we are connected
        if (networkInfo != null && networkInfo.isConnected()) {
            return true;
        }
        return false;
    }



    public  void  GetText()  throws  UnsupportedEncodingException
    {

        FirebaseInstanceId.getInstance().getInstanceId()
                .addOnCompleteListener(new OnCompleteListener<InstanceIdResult>() {
                    @Override
                    public void onComplete(@NonNull Task<InstanceIdResult> task) {
                        if (!task.isSuccessful()) {
                            Log.w("MainActivity", "getInstanceId failed", task.getException());
                            return;
                        }

                        // Get new Instance ID token
                        String token = task.getResult().getToken().toString();

                        // Log and toast
                        String msg = getString(R.string.Token,token);
                        Log.d("Token generation", msg);
                        Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show();
t1.setText(token);
                        sendData(t1.getText().toString());
                    }});
    }

    public void sendData(String token){
              OkHttpClient client = new OkHttpClient();

                RequestBody formBody = new FormBody.Builder()
                        .add("token", token)
                        .build();
                Request request = new Request.Builder()
                        .url("http://192.168.1.7:90/App/data.php")
                        .post(formBody)
                        .build();
                client.newCall(request).enqueue(new Callback(){
                    @Override
                    public void onFailure(Call call, IOException e) {
                        Log.i("error","error occured");
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
            Log.i("response",response.body().string());
            }

        });

    }
}

